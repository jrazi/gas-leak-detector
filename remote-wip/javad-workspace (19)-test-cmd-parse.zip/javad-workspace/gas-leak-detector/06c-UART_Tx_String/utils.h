#ifndef UTILS_H
#define	UTILS_H

#include <string.h>

int StartsWith(const char *a, const char *b);
int EndsWith(const char *a, const char *b);

#endif



