

void Initialize_Data_Transfer(void);
void Send_Humidity_History(int minutes);
void Send_Valve_Command_History(int minutes);
