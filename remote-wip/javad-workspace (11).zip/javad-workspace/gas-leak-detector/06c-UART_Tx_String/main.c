
#include "LPC17xx.h"
#include "adc.h"
#include "uart.h"
#include "delay.h"
#include "stdutils.h"
#include "gpio.h"
#include "timer.h"
#include <stdio.h>
#include "gateway.h"
#include "config.h"
#include "store.h"

humidity_record humidity_record_buffer[10];

void print_store(void) 
{
	int i;
	
	Get_Latest_Humidity_Records(10, humidity_record_buffer);
	
	for (i = 0; i < 10 && i < (sizeof(humidity_record_buffer)/sizeof(humidity_record_buffer[0])); i++) 
	{
		UART2_Printf("TS: %s, Humidity: %d\r\n", humidity_record_buffer[i].timestamp, humidity_record_buffer[i].humidity_percentage);
	}
}

void ADC_ISR(void)
{
	 int adc_value;
	 float humidity_percentage;
	 humidity_record record;

   adc_value = ADC_GetAdcValue(3); 	
	 humidity_percentage= 100-(adc_value*100)/4096 ;
	
   UART2_Printf("***** ADC0 Value *****\r\n%4d\r\n***************\r\n",humidity_percentage);
	 Send_Humidity_Status((int) humidity_percentage);
	
	 strcpy(record.timestamp, "22, Jul, 2021");
	 record.humidity_percentage = (int) humidity_percentage;
	 Insert_Humidity_Record(record);
	 print_store();
}


void Valve_Command_ISR(void)
{	
	int valve_cmd;
	valve_cmd = Get_Valve_Open_Cmd();
	
	UART2_Printf("***** Valve Open Status *****\r\n%d\r\n***************\r\n", valve_cmd);

	if (valve_cmd == 1)
	{
		GPIO_PinWrite(2, 0x00000022);
	}
	else if (valve_cmd == 0)
	{
		GPIO_PinWrite(2, 0x000000cc);
	}
}


int main() 
{
		int wifi_intialized = 0;
		//***********************Initialization********************************////////
		
	  SystemInit();
	  TIMER_Init(0,ADC_TIMER_INTERVAL_MS * 1000);                  
		TIMER_Init(1, VALVE_CMD_INTERVAL_MS * 1000);                 
	  ADC_Init();                             /* Initialize the ADC module */
	  UART2_Init(115200);                     /* Initialize UART2 for serial commmunication with PC */
	  UART1_Init(115200);											/* Initialize UART1 for ESP */
		Initialize_Store();
	
	  while (wifi_intialized <= 0) 
		{
				wifi_intialized = Initialize_Wifi();										  /* Initialize Wifi */
				if (wifi_intialized <= 0) 
				{
					UART2_Printf("Failed to connect to the access point. Going to try again. Status: %d\n\r", wifi_intialized);
				  DELAY_ms(500);
					Reset_Wifi();
					DELAY_ms(1000);
					continue;
				}
				else 
				{
				  UART2_Printf("Connected to access point with success!\n\r");
					break;
				}
		}
			
	
	//*******************************END******************************************/////
	
	//*********************GPIO-Seven segment init**************************************////////
	 
	GPIO_PinDirection(P2_0,OUTPUT);
	GPIO_PinDirection(P2_1,OUTPUT);
	GPIO_PinDirection(P2_2,OUTPUT);
	GPIO_PinDirection(P2_3,OUTPUT);
	GPIO_PinDirection(P2_4,OUTPUT);
	GPIO_PinDirection(P2_5,OUTPUT);
	GPIO_PinDirection(P2_6,OUTPUT);
	GPIO_PinDirection(P2_7,OUTPUT);

	//********************************END**************************************************///////////
	
		

	//***********************Timers Interrupt Initialization****************************///

    TIMER_AttachInterrupt(0, ADC_ISR);       
    TIMER_AttachInterrupt(1, Valve_Command_ISR);     
		
		TIMER_Start(0); 
	//	DELAY_ms(2500);
		TIMER_Start(1);
		
		while (1) {
			DELAY_ms(1);
		}

//*****************************END*************************************************///////// 

}

