#ifndef STORE_H
#define	STORE_H

#include "stdutils.h"

#define RECORD_EXPIRE_MINUTES 5


typedef struct 
{
    char timestamp[32];
    uint8_t humidity_percentage;
} humidity_record;

typedef struct
{
    char timestamp[32];
    uint8_t valve_cmd;
} valve_cmd_record;

void Initialize_Store(void);

void Insert_Humidity_Record(humidity_record record);
void Insert_Valve_Cmd_Record(valve_cmd_record record);

void Get_Latest_Humidity_Records(int since_minutes_ago, humidity_record* buffer);
void Get_Latest_Valve_Cmd_Records(int since_minutes_ago, valve_cmd_record* buffer);

#endif

