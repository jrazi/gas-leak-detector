/***************************************************************************************************
                                   ExploreEmbedded
****************************************************************************************************
 * File:   main.c
 * Version: 16.0
 * Author: ExploreEmbedded
 * Website: http://www.exploreembedded.com/wiki
 * Description: This file contains the program to read 10bit ADC value from channel 0 and send it on UART.

The libraries have been tested on ExploreEmbedded development boards. We strongly believe that the
library works on any of development boards for respective controllers. However, ExploreEmbedded
disclaims any kind of hardware failure resulting out of usage of libraries, directly or indirectly.
Files may be subject to change without prior notice. The revision history contains the information
related to updates.


GNU GENERAL PUBLIC LICENSE:
    Copyright (C) 2012  ExploreEmbedded
  
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.


Errors and omissions should be reported to codelibraries@exploreembedded.com
**************************************************************************************************/
#include "LPC17xx.h"
#include "adc.h"
#include "uart.h"
#include "delay.h"
#include "stdutils.h"
#include "gpio.h"
#include "timer.h"
#include <stdio.h>
#include <string.h>
#include "wifi.h"

volatile  int adcValue;
volatile  float H_PERCENT;
char str[200];
char receive_buffer[100] = "";
char last_received_char;
int reading_last_line = 0;
char apikeys[32]="alshldhgashg";
void  myTimerIsr_0(void)
{
   adcValue = ADC_GetAdcValue(3); // Read the ADC value of channel zero
	 H_PERCENT= 100-(adcValue*100)/4096 ;
//	 sprintf (str,"AT+CWMODE=3%c%c",0x0d,0x0a);
//	 UART0_TxString(str);
//	 DELAY_ms(100);
	
   UART2_Printf("ADC0 Value:%4d \n\r",H_PERCENT);     // Send the value on UART
	
}
///*******SEVEN-SEGMENT IMPLEMENTATION****///////
void  myTimerIsr_1(void)
{
	
//    GPIO_PinToggle(P2_0);
//	  DELAY_ms(100);
//	  GPIO_PinToggle(P2_1);
//	  DELAY_ms(100);
//	  GPIO_PinToggle(P2_2);
//	  DELAY_ms(100);
//	  GPIO_PinToggle(P2_3);
//	  DELAY_ms(100);
	
//	  GPIO_PinToggle(P2_4);
//	  DELAY_ms(100);
//	  GPIO_PinToggle(P2_5);
//	  DELAY_ms(100);
//	  GPIO_PinToggle(P2_6);
//	  DELAY_ms(100);
//	  GPIO_PinToggle(P2_7);
//	  DELAY_ms(100);
	
}


void wifi_receive_handler(void) {
			char received;
      char *last_four_recveived;
      char *last_two_recveived;

	    int len;
	
			received = UART1_ReadRDR();

			if (received != NULL && received != 0 && received != '\0') {
					strncat(receive_buffer, &received, 1);

					len = strlen(receive_buffer);
				
					last_two_recveived = len >= 4 ? &receive_buffer[len-2] : "";
					last_four_recveived = len >= 4 ? &receive_buffer[len-4] : "";
				
				  if (reading_last_line == 1 && strcmp(last_two_recveived, "\r\n") == 0) {
						reading_last_line = 0;
						UART2_Printf("****** Received Message From Wifi Module ******\r\n%s*******************\r\n", receive_buffer);
						receive_buffer[0] = '\0';
					}
					if (strcmp(last_four_recveived, "\r\n\r\n") == 0) {
						reading_last_line = 1;
					}
			}
			else {
				UART2_Printf("null char received %s \r\n", receive_buffer);
			}
}

void wifi_receive_line_by_line_handler(void) {
			char received;
	
			received = UART1_ReadRDR();

			if (received != NULL && received != '\0' && received != 0) {
					strncat(receive_buffer, &received, 1);
			}
}

int main() 
{
	char* tcp_packet;
	int packet_len;
	//***********************Initialization********************************////////
	
	  SystemInit();
    TIMER_Init(0,1000000);                  /* Configure timer0 to generate 100ms(100000us) delay*/
    TIMER_Init(1,500000);                  /* Configure timer1 to generate 500ms(500000us) delay*/
	  ADC_Init();                               /* Initialize the ADC module */
	  UART2_Init(115200);                          /* Initialize UART at 9600 baud rate */
	  UART1_Init(115200);

		Initialize_Wifi();

 //   UART1_AttachInterrupt(wifi_receive_handler);
	
	
	//*******************************END******************************************/////
	
	//*********************GPIO-Seven segment init**************************************////////
	 
	GPIO_PinDirection(P2_0,OUTPUT);
	GPIO_PinDirection(P2_1,OUTPUT);
	GPIO_PinDirection(P2_2,OUTPUT);
	GPIO_PinDirection(P2_3,OUTPUT);
	GPIO_PinDirection(P2_4,OUTPUT);
	GPIO_PinDirection(P2_5,OUTPUT);
	GPIO_PinDirection(P2_6,OUTPUT);
	GPIO_PinDirection(P2_7,OUTPUT);
	

	//********************************END**************************************************///////////
	
	//*********************Config ESP8266************************************/////////
 
//	UART1_TxString("AT+RST\r\n"); --> Resets the module. 	
//	DELAY_ms(100);
	



		
//	tcp_packet = "GET / HTTP/1.1\r\nHost: 1.1.1.1\r\n\r\n";
	tcp_packet = "GET /channels/1408802/fields/2/last.json?api_key=FSLIKU9TBV4ERAJJ HTTP/1.1\r\nHost: api.thingspeak.com\r\n\r\n";
	packet_len = strlen(tcp_packet);

  sprintf(str, "AT+CIPSEND=%d\r\n", packet_len);
	UART1_TxString(str);
	DELAY_ms(100);

	UART1_TxString(tcp_packet);
	DELAY_ms(5000);

  UART1_TxString("AT\r\n");
	DELAY_ms(100);

	UART1_TxString("AT\r\n");
	DELAY_ms(100);

//	UART1_TxString("AT+CIPCLOSE\r\n");
//	DELAY_ms(100);


	//****************************END******************************////////////////////
	
	//***********************Timers Intialization****************************///

    TIMER_AttachInterrupt(0,myTimerIsr_0);       /* myTimerIsr_0 will be called by TIMER0_IRQn */
    TIMER_AttachInterrupt(2,myTimerIsr_1);       /* myTimerIsr_1 will be called by TIMER1_IRQn */
		
		
		TIMER_Start(0);                            /* Start the Timers */
		TIMER_Start(1);

//*****************************END*************************************************///////// 
    

}

