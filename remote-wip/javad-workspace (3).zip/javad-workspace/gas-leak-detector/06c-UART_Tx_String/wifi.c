

#include <stdarg.h>
#include "wifi.h"
#include "stdutils.h"
#include "uart.h"
#include "delay.h"
#include "utils.h"
#include <string.h>

char at_response_buffer[1000] = "";

wifi_status_st WifiStatus = {  NULL, NULL, 0, 0};

typedef struct
{ 
	int ok;
	char* text;
} at_response;

at_response response;

at_response Get_Command_Response(void) {
	char received;
	int done = 0;
	long counter = 0;
	int us_unit = 23;
	int timeout_ms = 8000;
	long counter_max = timeout_ms*20*us_unit;
	
	
	strcpy(at_response_buffer, "");
	response.text = "";
	
//	UART2_Printf("HANDLING RESPONSE\r\n");

	while (!done && counter < counter_max) {
		DELAY_us(1);
	//	UART2_Printf("%d\r\n", counter);
		counter++;
		received = UART1_ReadRDR();
		if (received == NULL)
			continue;
	//	UART2_Printf("char: %c\r\n", received);
    strncat(at_response_buffer, &received, 1);
		if (EndsWith(at_response_buffer, "OK\r\n")) {
			response.ok = 1;
			response.text = at_response_buffer;
			done = 1;
		}
		else if (EndsWith(at_response_buffer, "ERROR\r\n")) {
			response.ok = 0;
			response.text = at_response_buffer;
			done = 1;
		}
	}
	
	
	UART2_Printf("****** WIFI RESPONSE ******\r\n%s\r\n*******************\r\n", response.text);
	return response;
}


int Initialize_Wifi(void) {
	at_response response;
	
	UART2_Printf("WIFI INIT\r\n");

	UART1_TxString("AT\r\n");
	
	response = Get_Command_Response();
	

	if (response.ok <= 0) 
		return -1;
	

	UART1_TxString("AT+CWMODE=3\r\n");

	response = Get_Command_Response();

	if (response.ok <= 0) 
		return -1;	
	
	UART0_TxString("AT+CIPMUX=0\r\n");
	
	response = Get_Command_Response();

	if (response.ok <= 0) 
		return -1;

	UART1_TxString("AT+CWJAP=\"MPLab\",\"MpProject1400\"\r\n");
	
	response = Get_Command_Response();

	if (response.ok <= 0) 
		return -1;

  
	UART1_TxString("AT+CIFSR\r\n");
	
	response = Get_Command_Response();

	if (response.ok <= 0) 
		return -1;

	return 1;
}

void Send_HTTP_Request_NonBlocking(atResponseHandlerFunPtr callback);
char* Send_HTTP_Request(char* http_request);
int Is_Ready_to_Send(void);
wifi_status_st Get_Status(void);






