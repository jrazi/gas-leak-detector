
int StartsWith(const char *a, const char *b);
int EndsWith(const char *a, const char *b);

