
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: '06c-UART_Tx_String' 
 * Target:  'javad-space' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "LPC17xx.h"

/*  Keil::Data Exchange:JSON:Jansson:2.7.0 */
#define JANSSON
/*  MDK-Packs::IoT Utility:http-parser:2.9.2 */
#define RTE_IoT_HTTP_PARSER             /* HTTP Parser */


#endif /* RTE_COMPONENTS_H */
