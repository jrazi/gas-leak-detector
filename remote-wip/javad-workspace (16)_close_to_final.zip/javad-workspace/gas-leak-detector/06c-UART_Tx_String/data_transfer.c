
#include "data_transfer.h"
#include "store.h"
#include "uart.h"
#include "delay.h"
#include <string.h>

void Send_Humidity_History(int minutes) 
{
	int i;
	humidity_record humidity_record_buffer[500] = {NULL, NULL};
	char* default_time = "                             ";
	int num_records = 0;
	num_records = Get_Latest_Humidity_Records(minutes, humidity_record_buffer);
	
	UART2_Printf("*** Humidity Recrods From %d Minutes Ago ***\r\n", 5);
	DELAY_us(100);

	for (i = 0; (i < 500) && (i < num_records); i++) 
	{
		char* time = strlen(humidity_record_buffer[i].timestamp) > 0 ? humidity_record_buffer[i].timestamp : default_time; 

		UART2_Printf("Time: %s, Humidity: %d %%\r\n", time, humidity_record_buffer[i].humidity_percentage);
		DELAY_us(100);
	}
	UART2_Printf("****************\r\n");
}

void Send_Valve_Command_History(int minutes) 
{
	int i;
	valve_cmd_record valve_cmd_record_buffer[500] = {NULL, NULL};
	char* default_time = "                             ";
	int num_records = 0;

	num_records = Get_Latest_Valve_Cmd_Records(minutes, valve_cmd_record_buffer);
	
	UART2_Printf("*** Valve Command Recrods From %d Minutes Ago ***\r\n", 5);
	DELAY_us(100);

	for (i = 0; (i < 500) && (i < num_records); i++) 
	{
		char* time = strlen(valve_cmd_record_buffer[i].timestamp) > 0 ? valve_cmd_record_buffer[i].timestamp : default_time; 
		char* valve_status = valve_cmd_record_buffer[i].valve_cmd == 1 ? "W" : "D";
		
		UART2_Printf("Time: %s, Valve Status: %s\r\n", time, valve_status);
		DELAY_us(100);
	}
	UART2_Printf("****************\r\n");
}
