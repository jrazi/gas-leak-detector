

void Send_Humidity_History(int minutes);
void Send_Valve_Command_History(int minutes);
