
#include "data_transfer.h"
#include "store.h"
#include "uart.h"
#include "delay.h"
#include <string.h>
#include "utils.h"
#include <stdlib.h>

char command_buffer[64] = "";
char last_command[64] = "";

void UART2_DT_ISR(void);
void Parse_Command(void);

void test(void)
{
	strcpy(last_command , "humidity 3 >");
	Parse_Command();
	
	strcpy(last_command , "valve 1 >");
	Parse_Command();

	strcpy(last_command , "humidity   8   >");
	Parse_Command();

	strcpy(last_command , "valve s >");
	Parse_Command();

	strcpy(last_command , "valvdse s >");
	Parse_Command();
	
	strcpy(last_command , " valve 2 >");
	Parse_Command();

	strcpy(last_command , "humidity 2 >");
	Parse_Command();

	strcpy(last_command , "");
}

void Initialize_Data_Transfer(void) {
  UART2_AttachInterrupt(UART2_DT_ISR);	
}

void Send_Humidity_History(int minutes) 
{
	int i;
	humidity_record humidity_record_buffer[500] = {NULL, NULL};
	char* default_time = "                             ";
	int num_records = 0;
	num_records = Get_Latest_Humidity_Records(minutes, humidity_record_buffer);
	
	UART2_Printf("*** Humidity Recrods From %d Minutes Ago ***\r\n", minutes);
	DELAY_us(10);

	for (i = 0; (i < 500) && (i < num_records); i++) 
	{
		char* time = strlen(humidity_record_buffer[i].timestamp) > 0 ? humidity_record_buffer[i].timestamp : default_time; 

		UART2_Printf("Time: %s, Humidity: %d %%\r\n", time, humidity_record_buffer[i].humidity_percentage);
		DELAY_us(10);
	}
	UART2_Printf("****************\r\n");
}

void Send_Valve_Command_History(int minutes) 
{
	int i;
	valve_cmd_record valve_cmd_record_buffer[500] = {NULL, NULL};
	char* default_time = "                             ";
	int num_records = 0;

	num_records = Get_Latest_Valve_Cmd_Records(minutes, valve_cmd_record_buffer);
	
	UART2_Printf("*** Valve Command Recrods From %d Minutes Ago ***\r\n", minutes);
	DELAY_us(10);

	for (i = 0; (i < 500) && (i < num_records); i++) 
	{
		char* time = strlen(valve_cmd_record_buffer[i].timestamp) > 0 ? valve_cmd_record_buffer[i].timestamp : default_time; 
		char* valve_status = valve_cmd_record_buffer[i].valve_cmd == 1 ? "W" : "D";
		
		UART2_Printf("Time: %s, Valve Status: %s\r\n", time, valve_status);
		DELAY_us(10);
	}
	UART2_Printf("****************\r\n");
}


void Get_Second_Word(char* str, char* word_buffer);

void Parse_Command(void) 
{
	
	char minutes_str[8] = "";
	int minutes = 0;
	
	Get_Second_Word(last_command, minutes_str);
	
	if (strlen(minutes_str) == 0)
		return;
	
	minutes = atoi(minutes_str);

	if (minutes <= 0)
		return;
	
	if ( StartsWith(last_command, "humidity") )
	{
		Send_Humidity_History(minutes);
	}
	else if ( StartsWith(last_command, "valve") )
	{
		Send_Valve_Command_History(minutes);
	}
}

void UART2_DT_ISR(void)
{

	char received;
//	UART2_Printf("ISR: RRRRR\r\n");

	received = UART2_ReadRDR();

	if (received == NULL)
		return;
	
//	UART2_Printf("ISR: %c\r\n", received);
  strncat(command_buffer, &received, 1);
	if (received == '>' || received == '\n')
	{
		strcpy(last_command, command_buffer);
		strcpy(command_buffer, "");
		Parse_Command();
	}
}

void Get_Second_Word(char* str, char* word_buffer) 
{
	int i;
	int start_index = -1;
	int last_index = -1;
	int first_non_ws_char = 0;
	int first_ws = 0;
	int second_word_began = 0;
	
	for (i = 0; i < strlen(str); i++)
	{
		char c = str[i];
		if (c != ' ' && !first_non_ws_char)
		{
			first_non_ws_char = 1;
		}
		else if (c == ' ' && first_non_ws_char && !first_ws)
		{
			first_ws = 1;
		}
		else if (c != ' ' && first_non_ws_char && first_ws && !second_word_began)
		{
			second_word_began = 1;
			start_index = i;
		}
		else if (second_word_began && c == ' ')
		{
			last_index = i - 1;
		}
	}
	if ((last_index < start_index) || (last_index < 0) || (start_index < 0) )
	{
		strcpy(word_buffer, "");
		return;
	}
	
	strncpy(word_buffer, &str[start_index], last_index - start_index + 1);
  strncat(word_buffer, "\0", 1);

}

