#include "gateway.h"
#include "uart.h"



int Send_Humidity_Status(int humidityPercentage, humidity_record* response_record) {
	char http_raw_request[128] = "";
	char date[32] = "";
	char write_response_buffer[650] = "";

	write_response_buffer[0] = '\0';
	sprintf(http_raw_request, "GET /update?api_key=%s&field1=%d HTTP/1.1\r\nHost: %s\r\n\r\n", WRITE_API_KEY, humidityPercentage, API_DOMAIN);

  Send_HTTP_Request(http_raw_request, write_response_buffer);
	Get_Response_Header(write_response_buffer, "Date", date);

	strcpy(response_record->timestamp, date);
	response_record->humidity_percentage = humidityPercentage;
	
	return 1;
}

int Get_Valve_Open_Cmd(valve_cmd_record* response_record) {

	char http_raw_request[128] = "";
	char date[32] = "";
	char read_response_buffer[800] = "";
	char body_buffer[400] = "";

	sprintf(http_raw_request, "GET /channels/1408802/fields/2/last.json?api_key=%s HTTP/1.1\r\nHost: %s\r\n\r\n", READ_API_KEY, API_DOMAIN);

  Send_HTTP_Request(http_raw_request, read_response_buffer);
	Get_Response_Header(read_response_buffer, "Date", date);	
  Get_Response_Body(read_response_buffer, body_buffer);
  
	strcpy(response_record->timestamp, date);
	response_record->valve_cmd = Get_Valve_Open_Cmd_From_Json_Text(body_buffer);
		
	return 1;
}

